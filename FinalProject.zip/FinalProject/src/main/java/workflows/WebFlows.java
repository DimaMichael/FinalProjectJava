package workflows;

import extensions.UIActions;
import extensions.Verifications;
import io.qameta.allure.Step;
import utilities.CommonOps;


public class WebFlows extends CommonOps {

    @Step("Business Flow: Login")
    public static void login(String user, String pass) {
        UIActions.updateText(ladyMakeupLogin.txt_username, user); //DimArbazi
        UIActions.updateText(ladyMakeupLogin.txt_password, pass); //123456Dima!
        UIActions.click(ladyMakeupLogin.btn_login);
    }

    @Step("Business Flow: Choose a Makeup")
    public static void makeupChoose() throws InterruptedException {
        UIActions.mouseHover(ladyMakeupCategoryNavbar.btn_accessories);
        UIActions.click(ladyMakeupAccessories.btn_makeup_boxes);
    }

    @Step("Business Flow: Order Item")
    public static void orderItem() throws InterruptedException {
        UIActions.click(makeupBoxesPage.btn_order);

    }

    @Step("Business Flow: Delete Last Item")
    public static void deleteItem() throws InterruptedException {
        UIActions.click(ladyMakeupMain.btn_cart);
        Thread.sleep(2000);
        UIActions.click(ladyMakeupCartPage.btn_deleteItem);
        Thread.sleep(2000);
        UIActions.alertAccept();
    }

    @Step("Business Flow: Choose 4 Items ") //Need to check if its ok!
    public static void chooseManyItems(String amount) throws InterruptedException {
        UIActions.mouseHover(ladyMakeupCategoryNavbar.btn_accessories);
        UIActions.click(ladyMakeupAccessories.btn_puffs_and_sponges);
        UIActions.click(makeupPuffsAndSpongesPage.btn_orderPuff);
        UIActions.click(ladyMakeupMain.btn_cart);
        UIActions.updateDropDown(ladyMakeupCartPage.btn_amountOfProducts, amount);
        UIActions.click(ladyMakeupCartPage.btn_saveChanges);
        UIActions.click(ladyMakeupCartPage.btn_deleteItem);
        UIActions.alertAccept();
    }



//
//        if (shouldExist.equalsIgnoreCase("not exist"))
//            Verifications.existenceOfElement(ladyMakeupMain.txt_afterSearchNotExist);
//        else if (shouldExist.equalsIgnoreCase("exist"))
//            Verifications.notExistenceOfElement(ladyMakeupMain.txt_afterSearchNotExist);
//        else
//            throw new RuntimeException("Invalid Expected Output in Data Driven testing");
//    }
//    @Step("Business Flow: Search And Verify Item") //Need to check if its ok!
//    public static void searchAndVerifyItem(String itemName ,String shouldExist) {
//        UIActions.updateText(ladyMakeupMain.txt_search, itemName);
//        UIActions.click(ladyMakeupMain.btn_searchSubmit);
//        if (shouldExist.equalsIgnoreCase("not exist"))
//            Verifications.existenceOfElement(ladyMakeupMain.txt_afterSearchNotExist);
//        else if (shouldExist.equalsIgnoreCase("exist"))
//            Verifications.notExistenceOfElement(ladyMakeupMain.txt_afterSearchNotExist);
//        else
//            throw new RuntimeException("Invalid Expected Output in Data Driven testing");
//    }
}