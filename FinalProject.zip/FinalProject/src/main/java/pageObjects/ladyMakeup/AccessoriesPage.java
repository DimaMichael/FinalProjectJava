package pageObjects.ladyMakeup;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class AccessoriesPage {
    @FindBy(how = How.XPATH, using = "//li[@data-category-id='60']/a")
    public WebElement btn_makeup_boxes;

    @FindBy(how = How.XPATH, using = "//li[@data-category-id='61']/a")
    public WebElement btn_cosmetic_bags;

    @FindBy(how = How.XPATH, using = "//li[@data-category-id='67']/a")
    public WebElement btn_puffs_and_sponges;

    @FindBy(how = How.XPATH, using = "//li[@data-category-id='80']/a")
    public WebElement btn_chairs;







//-----------------------------------------------------
//    @FindBy(how = How.XPATH, using = "//a[@class='d-flex justify-content-between border-bottom p-2 pl-3']")
//    public WebElement link_makeup_boxes;
//
//    @FindBy(how = How.XPATH, using = "//a[@class='d-flex justify-content-between border-bottom p-2 pl-3']")
//    public WebElement link_cosmetic_bags;
//
//    @FindBy(how = How.XPATH, using = "//a[@class='d-flex justify-content-between border-bottom p-2 pl-3']")
//    public WebElement link_puffs_and_sponges;
//
//    @FindBy(how = How.XPATH, using = "//a[@class='d-flex justify-content-between border-bottom p-2 pl-3']")
//    public WebElement link_chairs;


}

